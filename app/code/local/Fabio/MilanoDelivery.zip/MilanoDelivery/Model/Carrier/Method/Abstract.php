<?php
 
abstract class Fabio_MilanoDelivery_Model_Carrier_Method_Abstract 
{   
    abstract public function getCost();
    abstract public function getPrice();
} 