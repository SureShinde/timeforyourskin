<?php
class Mirasvit_SeoFilter_Helper_Code extends Mirasvit_MstCore_Helper_Code
{
    protected $k = "S59VZ2QIPJ";
    protected $s = "SEO";
    protected $l = "9497";
    protected $v = "1.1.1";
    protected $b = "890";
    protected $d = "zedlabz.com";
}
